Marc Tibbs, Brad Besserman, Yau Chan
March 16, 2018
TSP Project

Files Included:
TSP_SA.c
nrutil.c
nrutil.h
README

1) Ensure that all files are in the same directory. 
2) Compile the program enter “gcc TSP_SA.c nrutil.c nrutil.h -lm <filename>”. 
3) To run the program enter “./<filename> <testfile.txt>”.
4) The program will output a text file with the same name as the <testfile.txt> with “.tour” appended to the file name.


