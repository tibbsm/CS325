Marc Tibbs (tibbsm@oregonstate.edu)
January 21, 2018
HW2

Files Included:
stoogesort.cpp
README.txt

1) To run the stoogesort program on the flip server, ensure that the “data.txt” file is in the same folder as the stoogesort.cpp. While in that directory compile the program by typing “g++ stoogesort.cpp”. At this point you may choose to rename the program file using the -o directive.  To run the program simply type “./a.out” or “./“ and whatever name you chose to call the program file. Once the program is finished running it it will output a file called “stooge.out” in the same directory. 

*The program will prompt “File could not be opened.” if the text file is not located in the same directory as the program. 


