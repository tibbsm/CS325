Marc Tibbs (tibbsm@oregonstate.edu)
Feb. 18, 2018
HW5

Files Included:
wrestlers.py
README.txt

1) To compile the program type “python wrestlers.py [testfile.txt]”, where [testfile.txt] is the name of the file you wish to test. The program will output into the results into the console.

