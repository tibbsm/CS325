Marc Tibbs (tibbsm@oregonstate.edu)
Feb. 4, 2018
HW4

Files Included:
lastToStart.cpp
act.txt
README.txt

1) To run the lastToStart program on the flip server, ensure that the “act.txt” file is in the same folder as the lastToStart.cpp. While in that directory compile the program by typing “g++ lastToStart.cpp”. At this point you may choose to rename the program file using the -o directive.  To run the program simply type “./a.out” or “./“ and whatever name you chose to call the program file. The program will output into the results into the console.

*The program will prompt “File could not be opened.” if the text file is not located in the same directory as the program. 


